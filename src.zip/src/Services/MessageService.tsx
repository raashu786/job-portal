import { create } from 'zustand';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { toast } from 'react-toastify';
import { axiosInstance } from './AuthService';

export interface MessageDTO {
  id: number;
  senderId: number;
  receiverId: number;
  text: string;
  image?: string;
  createdAt: string;
  updatedAt: string;
  receiverName?: string;
}

interface ChatState {
  messages: MessageDTO[];
  users: any[];
  selectedUser: any | null;
  isUsersLoading: boolean;
  isMessagesLoading: boolean;
  stompClient: Client | null;

  getUsers: () => Promise<void>;
  getMessages: (userId: number) => Promise<void>;
  sendMessage: (messageData: FormData) => Promise<void>;
  subscribeToMessages: (senderId: number) => void;
  unsubscribeFromMessages: () => void;
  setSelectedUser: (user: any) => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  users: [],
  selectedUser: null,
  isUsersLoading: false,
  isMessagesLoading: false,
  stompClient: null,

  getUsers: async () => {
    set({ isUsersLoading: true });
    try {
      const res = await axiosInstance.get("/profiles/getAll");
      set({ users: res.data });
    } catch (error: any) {
      console.error(error?.response?.data?.message || "Error fetching users");
    } finally {
      set({ isUsersLoading: false });
    }
  },

  getMessages: async (userId: number) => {
  set({ isMessagesLoading: true });
  const user = JSON.parse(localStorage.getItem("user") as string);
  const senderId = user?.profileId;

  try {
    const res = await axiosInstance.get(`/api/messages/${userId}`, {
    });
    console.log()
    set({ messages: res.data });
  } catch (error: any) {
    toast.error(error?.response?.data?.message || "Error fetching messages");
  } finally {
    set({ isMessagesLoading: false });
  }
},

  sendMessage: async (messageData: FormData) => {
  const { selectedUser, messages, stompClient } = get();
  const user = JSON.parse(localStorage.getItem("user") as string);
  const senderId = user?.profileId;

  if (!selectedUser) {
    toast.error("No recipient selected");
    return;
  }

  try {
    await waitForConnection();
    const res = await axiosInstance.post(
      `/api/messages/${selectedUser.id}`,
      messageData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
          'X-User-Id': senderId,
        },
      }
    );

    const newMessage = res.data;
    set({ messages: [...messages, newMessage] });

  } catch (error: any) {
    console.error(error?.response?.data?.message || "Error sending message");
    toast.error("Failed to send message.");
  }
},

subscribeToMessages: (senderId: number) => {
  const { stompClient } = get();

  if (stompClient && stompClient.connected) {
    console.log("⚠ Already connected. No need to re-subscribe.");
    return;
  }

   const client = new Client({
    webSocketFactory: () => new SockJS('http://localhost:8080/ws'),
    connectHeaders: { userId: senderId.toString() },
    debug: (str) => console.log(str),
    reconnectDelay: 5000,
    heartbeatIncoming: 4000,
    heartbeatOutgoing: 4000,
    onConnect: () => {
      console.log("✅ WebSocket connected");
      
      client.subscribe(`/user/${senderId}/queue/messages`, (msg) => {
        const receivedMessage: MessageDTO = JSON.parse(msg.body);
        set((state) => {
          if (!state.messages.some(m => m.id === receivedMessage.id)) {
            return { messages: [...state.messages, receivedMessage] };
          }
          return state;
        });
      });
    },

    onStompError: (frame) => {
      console.error('Broker error:', frame.headers.message, frame.body);
      toast.error("Real-time connection error.");
    },

    onDisconnect: () => {
      console.warn("🛑 WebSocket disconnected");
    }
  });

  client.activate();
  set({ stompClient: client });
}
,

  unsubscribeFromMessages: () => {
    const { stompClient } = get();
    if (stompClient) {
      stompClient.deactivate();
      set({ stompClient: null });
      console.log("🛑 WebSocket disconnected");
    }
  },

  setSelectedUser: (user) => {
    set({ selectedUser: user, messages: [] });
  },
}));

const waitForConnection = () => {
  return new Promise<void>((resolve) => {
    const check = () => {
      const client = useChatStore.getState().stompClient;
      if (client?.connected) resolve();
      else setTimeout(check, 200);
    };
    check();
  });
};
