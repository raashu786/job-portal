import React, { useEffect, useState } from 'react';
import { useChatStore } from '../Services/MessageService';



const Message = () => {
  const {
    messages,
    getMessages,
    sendMessage,
    subscribeToMessages,
    unsubscribeFromMessages,
    selectedUser,
    setSelectedUser,
  } = useChatStore();

  const [text, setText] = useState('');

  useEffect(() => {
    const userId = Number(localStorage.getItem("userId"));
    if (!userId) return;

    subscribeToMessages(userId);
    return () => unsubscribeFromMessages();
  }, []);

  const handleSend = async () => {
    const formData = new FormData();
    formData.append('text', text);
    await sendMessage(formData);
    setText('');
  };

  return (
    <div>
      <div>{messages.map((m) => <p key={m.id}>{m.text}</p>)}</div>
      <input value={text} onChange={(e) => setText(e.target.value)} />
      <button onClick={handleSend}>Send</button>
    </div>
  );
};

