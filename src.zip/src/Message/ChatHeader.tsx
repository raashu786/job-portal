import { X } from "lucide-react";
import { useChatStore } from "../Services/MessageService";
import { useAuthStore } from "../Services/AuthService";
import { Badge } from "@mantine/core";



const ChatHeader = () => {
  const { selectedUser, setSelectedUser } = useChatStore();
  const { onlineUsers } = useAuthStore();

  if (!selectedUser) return null;

  return (
    <div className="p-2.5 border-b border-base-300">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="avatar">
            <div className="size-12 rounded-full relative">
              <img
                src={selectedUser.picture? `data:image/jpeg;base64,${selectedUser.picture}` : "/avatar-9.png"}
                alt={selectedUser.name}
                 className="size-12 object-cover rounded-full"
              />
            </div>
          </div>

          <div>
            <h3 className="font-medium">{selectedUser.name}</h3>
            <p className="text-sm text-base-content/70">
              {onlineUsers.includes(selectedUser._id) ? <Badge variant="light" color="green">Online</Badge> : <Badge variant="light"  radius="xs" color="blue">Offline</Badge>}
            </p>
          </div>
        </div>

        <button onClick={() => setSelectedUser(null)}>
          <X />
        </button>
      </div>
    </div>
  );
};

export default ChatHeader;
